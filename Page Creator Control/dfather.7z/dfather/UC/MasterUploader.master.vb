﻿
Partial Class MasterUploader
    Inherits System.Web.UI.MasterPage
End Class

