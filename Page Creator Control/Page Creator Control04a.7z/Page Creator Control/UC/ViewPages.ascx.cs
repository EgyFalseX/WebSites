﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.IO;

public partial class ViewPages : System.Web.UI.UserControl
{
        #region -   Variables   -
    string constr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source= " + HttpContext.Current.Server.MapPath("./data/FlexibleData.mdb");
        #endregion
        #region -   Functions   -
    private DataTable LoadData()
    {
        DataTable dt = new DataTable("FX2012");
        using (OleDbDataAdapter da = new OleDbDataAdapter("SELECT ItemID, ItemName, Show_Hide, Data_Path FROM MenuItem ORDER BY ItemID", constr))
        {
            da.Fill(dt);
        }
        return dt;
    }

    public string LoadContain()
    {
        if (MainMenu.SelectedValue == "")
        {
            return "";
        }
        string ThePath = string.Empty;
        string RetData = string.Empty;
        using (OleDbConnection Con = new OleDbConnection(constr))
        {
            OleDbCommand cmd = new OleDbCommand(String.Format("SELECT Data_Path FROM MenuItem WHERE (ItemID = {0})", MainMenu.SelectedValue), Con);
            try
            {
                Con.Open();
                ThePath = cmd.ExecuteScalar().ToString();
                if (ThePath != string.Empty)
                    ThePath = MapPath(ThePath);
                if (File.Exists(ThePath))
                {
                    TextReader TR = new StreamReader(ThePath);
                    RetData = TR.ReadToEnd();
                    TR.Close();
                    TR.Dispose();
                }
            }
            catch (Exception ex)
            {
                RetData = ex.Message;
            }
            Con.Close();
        }
        //return System.Text.Encoding.GetEncoding(RetData).EncodingName;
        return HttpUtility.HtmlDecode(RetData);
        //return RetData;
    }
#endregion
        #region - Event Handlers -
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            foreach (DataRow row in LoadData().Rows)
            {
                MenuItem item = new MenuItem(row["ItemName"].ToString(), row["ItemID"].ToString());
                MainMenu.Items.Add(item);
            }
        }
    }
        #endregion         #region -   Variables   -


    
}