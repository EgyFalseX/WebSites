﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class ReplyMsg : System.Web.UI.UserControl
{

    private void LoadMsg()
    {
        DataTable MsgTbl = new DataTable();
        OleDbDataAdapter DA = new OleDbDataAdapter("", MySchool.ServicesConnection);
        switch (DDLMsgFilter.SelectedIndex)
        {
            case 0:// All Msg
                DA.SelectCommand.CommandText = @"SELECT MsgID, SenderName, SenderEmail, SenderTel, SenderMsg, SendDate, ReplyMsg, ReplyDate,
                (Select JobName From Jobs Where JobID = GeneralMsg.JobID) AS JobName, 
                (Select MsgTypeName From MsgType Where MsgTypeID = GeneralMsg.MsgTypeID) AS MsgTypeName
                FROM GeneralMsg";
                break;
            case 1://UnReply
                DA.SelectCommand.CommandText = @"SELECT MsgID, SenderName, SenderEmail, SenderTel, SenderMsg, SendDate, ReplyMsg, ReplyDate,
                (Select JobName From Jobs Where JobID = GeneralMsg.JobID) AS JobName, 
                (Select MsgTypeName From MsgType Where MsgTypeID = GeneralMsg.MsgTypeID) AS MsgTypeName
                FROM GeneralMsg Where ReplyMsg IS NULL";
                break;
            case 2://Reply
                DA.SelectCommand.CommandText = @"SELECT MsgID, SenderName, SenderEmail, SenderTel, SenderMsg, SendDate, ReplyMsg, ReplyDate,
                (Select JobName From Jobs Where JobID = GeneralMsg.JobID) AS JobName, 
                (Select MsgTypeName From MsgType Where MsgTypeID = GeneralMsg.MsgTypeID) AS MsgTypeName
                FROM GeneralMsg Where ReplyMsg <> NULL";
                break;
        }
        DA.Fill(MsgTbl);
        GridViewMsg.DataSource = MsgTbl;
        GridViewMsg.DataBind();
        ViewState["MsgTbl"] = MsgTbl;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        TheSessions.UserID = "123";

        if (TheSessions.UserID == null)
            Response.Redirect("~/SLDoTheLogin.aspx");// Admin
        else if (TheSessions.UserID.StartsWith("") == false)
            Response.Redirect("~/SLDoTheLogin.aspx");// Admin

        if (!IsPostBack)
        {
            LoadMsg();
            ViewState["MsgID"] = null;
        }
    }
    protected void DDLMsgFilter_SelectedIndexChanged(object sender, EventArgs e)
    {
        LoadMsg();
        PnlReply.Visible = false;
        LblState.Visible = false;
        ViewState["MsgID"] = null;
    }
    protected void GridViewMsg_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable MsgTbl = (DataTable)ViewState["MsgTbl"];
        ViewState["MsgID"] = MsgTbl.Rows[GridViewMsg.SelectedIndex]["MsgID"].ToString();
        TxtSndMsg.Text = MsgTbl.Rows[GridViewMsg.SelectedIndex]["SenderMsg"].ToString();
        PnlReply.Visible = true;
        LblState.Visible = false;
        TxtReplyMsg.Text = string.Empty;
        PnlReply.Focus();
    }
    protected void BtnSaveReply_Click(object sender, EventArgs e)
    {
        if (TxtReplyMsg.Text.Trim().Length == 0)
        {
            LblState.Text = "من فضلك ادخل نص الرد";
            LblState.ForeColor = System.Drawing.Color.Red;
            LblState.Visible = true;
            return;
        }
        OleDbConnection con = MySchool.ServicesConnection;
        OleDbCommand cmd = new OleDbCommand("", con);
        cmd.CommandText = string.Format(@"UPDATE GeneralMsg SET ReplyMsg = '{0}', ReplyDate = Format(Date(), 'dd/MM/yyyy'), UserID = '{1}'
                            WHERE GeneralMsg.MsgID = {2}", TxtReplyMsg.Text.Trim(), TheSessions.UserID, ViewState["MsgID"].ToString());
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            LblState.Text = "تم الرد";
            LblState.ForeColor = System.Drawing.Color.Green;
            LblState.Visible = true;
            LoadMsg();
        }
        catch (OleDbException ex)
        {
            LblState.Text = ex.Message;
            LblState.ForeColor = System.Drawing.Color.Red;
            LblState.Visible = true;
        }
        con.Close();
    }

}
