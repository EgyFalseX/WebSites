﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class SendMsg : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            LoadDefaultData();
    }
    private void LoadDefaultData()
    {
        DataTable Jobs = new DataTable("");
        DataTable MsgTypes = new DataTable("");
        OleDbDataAdapter DA = new OleDbDataAdapter("", MySchool.ServicesConnection);
        DA.SelectCommand.CommandText = "Select JobID, JobName from Jobs";
        DA.Fill(Jobs);
        DDLJobID.DataSource = Jobs;
        DDLJobID.DataTextField = "JobName";
        DDLJobID.DataValueField = "JobID";
        DDLJobID.DataBind();
        DA.SelectCommand.CommandText = "Select MsgTypeID, MsgTypeName from MsgType";
        DA.Fill(MsgTypes);
        DDLMsgTypeID.DataSource = MsgTypes;
        DDLMsgTypeID.DataTextField = "MsgTypeName";
        DDLMsgTypeID.DataValueField = "MsgTypeID";
        DDLMsgTypeID.DataBind();
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        if (TxtSenderName.Text.Trim().Length == 0)
        {
            LblState.Text = "من فضلك ادخل الاسم";
            LblState.ForeColor = System.Drawing.Color.Red;
            LblState.Visible = true;
            return;
        }
        if (DDLJobID.SelectedIndex == -1)
        {
            LblState.Text = "من فضلك اختار الوظيفه";
            LblState.ForeColor = System.Drawing.Color.Red;
            LblState.Visible = true;
            return;
        }
        if (TxtSenderEmail.Text.Trim().Length == 0)
        {
            LblState.Text = "من فضلك ادخل البريد";
            LblState.ForeColor = System.Drawing.Color.Red;
            LblState.Visible = true;
            return;
        }
        if (DDLMsgTypeID.SelectedIndex == -1)
        {
            LblState.Text = "من فضلك اختار نوع الرساله";
            LblState.ForeColor = System.Drawing.Color.Red;
            LblState.Visible = true;
            return;
        }
        if (TxtSenderMsg.Text.Trim().Length == 0)
        {
            LblState.Text = "من فضلك ادخل نص الرساله";
            LblState.ForeColor = System.Drawing.Color.Red;
            LblState.Visible = true;
            return;
        }
        string SenderTel = "NULL";
        if (TxtSenderTel.Text.Trim().Length != 0)
            SenderTel = "'" + TxtSenderTel.Text.Trim() + "'";

        OleDbConnection con = MySchool.ServicesConnection;
        OleDbCommand cmd = new OleDbCommand("", con);
        try
        {
            con.Open();
            cmd.CommandText = string.Format(@"INSERT INTO GeneralMsg
                      (SenderName, SenderEmail, JobID, MsgTypeID, SenderTel, SenderMsg, SendDate)
                      VALUES ('{0}', '{1}', {2}, {3}, {4}, '{5}', Format(Date(), 'dd/MM/yyyy'))",
                      TxtSenderName.Text.Trim(), TxtSenderEmail.Text.Trim(), DDLJobID.SelectedValue, DDLMsgTypeID.SelectedValue, SenderTel, TxtSenderMsg.Text.Trim());
            cmd.ExecuteNonQuery();
            LblState.Text = "تم الارسال";
            LblState.ForeColor = System.Drawing.Color.Green;
            LblState.Visible = true;
        }

        catch (OleDbException ex)
        {
            LblState.Text = ex.Message;
            LblState.ForeColor = System.Drawing.Color.Red;
            LblState.Visible = true;
        }
        con.Close();
    }
}