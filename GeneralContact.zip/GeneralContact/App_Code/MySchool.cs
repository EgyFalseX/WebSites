﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Data.OleDb;

/// <summary>
/// Summary description for MySchool
/// </summary>
public class MySchool
{

    public MySchool()
    {
        //
        // TODO: Add constructor logic here
        //

    }
    static string ConnectionStr(string DataBasename)
    {
        string constr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source= ";
        HttpServerUtility sv = HttpContext.Current.Server;

        constr += sv.MapPath(@"~\data\" + DataBasename);

        return constr;
    }
    static string ConnectionStr1(string DataBasename)
    {
        string constr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source= ";
        HttpServerUtility sv = HttpContext.Current.Server;

        constr += sv.MapPath(@"~\data\" + DataBasename);

        return constr;
    }
    public static OleDbConnection ServicesConnection
    {
        get
        {
            OleDbConnection con1 = new OleDbConnection(ConnectionStr(@"Services.mdb"));

            if (con1.State == ConnectionState.Open)
            {
                con1.Close();
            }
            return con1;
        }
    }
}