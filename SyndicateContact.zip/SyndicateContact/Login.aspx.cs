﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;
using System.Data.OleDb;

public partial class Login : Page
{

    private bool LogMeIn(string uid, string pss)
    {
        string constr = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source= " + HttpContext.Current.Server.MapPath(@"App_Data/contact.mdb");
        OleDbDataAdapter da = new OleDbDataAdapter(string.Format(@"Select [id], isadmin,
        (SELECT Top 1 LagnaId FROM UserAppilty WHERE pid = UserInfo.id) AS LagnaId,
        (SELECT Top 1 EdaraId FROM UserAppilty WHERE pid = UserInfo.id) AS EdaraId
        from UserInfo where [user] = '{0}' And pass = '{1}'", uid, pss), constr);
        DataTable dt = new DataTable();
        da.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            Codes.UserID = dt.Rows[0][0].ToString();
            if (Codes.IsNullOrEmpty(dt.Rows[0][1]))
                Codes.IsAdmin = false;
            else
                Codes.IsAdmin = (bool)dt.Rows[0][1];
            if (!Codes.IsNullOrEmpty(dt.Rows[0][2]))
                Codes.LagnaId = false;
            if (!Codes.IsNullOrEmpty(dt.Rows[0][3]))
                Codes.EdaraId = false;
            
            return true;
        }
        else
            return false;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Codes.IsAuthorized == false)
            PnlLogin.Visible = true;
        else
            PnlLogin.Visible = false;
        
    }
    protected void BtnLogin_Click(object sender, EventArgs e)
    {
        if (TxtUserName.Text == string.Empty || TxtPassword.Text == string.Empty)
        {
            LblState.Text = "من فضلك ادخل اسم المستخدم و كلمة المرور";
            LblState.ForeColor = Color.Red;
            return;
        }
        if (!LogMeIn(TxtUserName.Text, TxtPassword.Text))
        {
            LblState.Text = "خطاء في اسم المستخدم او كلمة السر";
            LblState.ForeColor = Color.Red;
            return;
        }

        if (Request.QueryString["RedirectURL"] == null)
            Response.Redirect("~/");
        else
            Response.Redirect(Request.QueryString["RedirectURL"]);
    }
}