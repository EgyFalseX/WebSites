using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MyDalLayerTableAdapters;

public partial class AddData : System.Web.UI.Page {

    protected void Button1_Click(object sender, EventArgs e) {

        int numItemsToAdd = Int32.Parse(NumAdd.Text);

        // Create new product category
        CategoriesTableAdapter categories = new CategoriesTableAdapter();
        categories.Insert(Server.HtmlEncode(CategoryName.Text));

        // Retrieve categoryId of our newly created Product Category
        int categoryId = (int) categories.GetCategoryIdByName(Server.HtmlEncode(CategoryName.Text));

        // Insert products and associate them with the new category
        ProductsTableAdapter products = new ProductsTableAdapter();

        for (int i = 0; i < numItemsToAdd; i++) {
            products.Insert(categoryId, Server.HtmlEncode(ProductName.Text) + ": " + i, "images/productimage.gif", new Decimal(99.9));
        }

        Label1.Text = numItemsToAdd + " rows created!";
    }
}
